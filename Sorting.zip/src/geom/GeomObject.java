/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geom;

import java.awt.*;

/**
 *
 * @author LTSACH
 */
public abstract class GeomObject {
    protected Color edgeColor;
    protected Color faceColor;
    protected int line_weight = 1;
    public GeomObject(){
        faceColor = new Color(20, 150, 20);
        edgeColor = new Color(150, 20, 20);
    }
}
